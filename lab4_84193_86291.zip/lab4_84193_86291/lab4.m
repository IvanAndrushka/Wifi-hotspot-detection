%% Laborat�rio 4
%Realizado por: Tiago Silva, 84193
%               Ivan Andrushka, 86291
%Objetivos: Construir e Simular um modelo do tipo cadeia de Markov 
%           Simular um sistema estoc�stico de Markov pelo m�todo de Monte Carlo 

%% Exerc�cio 2.a)
%
% Nesta al�nea iremos, atrav�s da determina��o dos valores e vetores
% pr�prios da matriz de probabilidades P, obter as probabilidades limite da
% cadeia de Markov
%
% Para isso temos de calcular os valores e vetores pr�prios da matriz P e
% normalizar o vetor pr�prio associado ao valor pr�prio 1, pois � este o
% vetor que verfica a condi��o de probabilidade limite: $\pi
% _{limite}^{T}=\pi _{limite}^{T}*P$
% , uma vez que a defini��o de vetor e valor pr�prio � a seguinte: 
% $P*v=\lambda *v$
% 

    warning off;
    
    load MarkovChain;
    [Vetores_prop, Valores_prop] = eig(transpose(P)); %Efetua o calculo dos vetores e valores pr�prios da matriz P^T

    % O ciclo seguinte percorre o todos os valores pr�prios e guarda a posi��o daquele que tem valor 1  
    for i=1:size(Valores_prop,1)
        if(round(Valores_prop(i,i),4)==1)
            break;
        end
    end
    
    vetor_normalizado_2a = abs((Vetores_prop(:,i))./(sum((Vetores_prop(:,i))))); 

    %Efetua a normaliza��o do vetor pr�prio escolhido, pois como estamos a
    %trabalhar com probabilidades, o somat�rio destas ter� de ser 1
    
    X=sprintf('Somat�rio das probabilidades limite=%.2f',sum(vetor_normalizado_2a));
    disp(X);
    
    figure(1);
    
    bar(vetor_normalizado_2a);
    xlabel ('states'); ylabel('prob');
    xlim([0 21]);
    title('Probabilidades Limite da Cadeia de Markov');
    
%% Comet�rios 2.a)
% Observando os resultados obtidos verificamos que os estados mais prov�veis
% s�o o 7 e 19 com uma probabilidade de 9,65% ,enquanto
% que os menos prov�veis s�o os estados 8 e 17 com uma probabildade de
% 1,07%. Isto � esperado quando se considera o grafo do qual se partiu,
% visto que o token passa por 7 e 19 sempre que vai para um dos ciclos em
% que tende a ficar. Por oposi��o os estados 8 e 17 pertencem a um ciclo
% onde o token n�o tende a estar.
%
%
%% Exerc�cio 2.b)
%
%  Estima��o da posi��o da fonte atrav�s do m�todo dos min�mos quadrados 
%  utilizando a fun��o rssiloc fornecida como exemplo
%
    observacoes = round(vetor_normalizado_2a.*1000);
    a = zeros(sum(observacoes), 2);
    k1 = 1;
    k2 = 0;

% Gera observa��es para cada ancora, de forma a poder resolver o problema
% de minimos quadrados ponderado

    for i=1:size(observacoes)
        k2 = k2+observacoes(i);
        a(k1:k2,:) = repmat([nodePos(i,2) nodePos(i, 3)], observacoes(i), 1);
        k1 = k1 + observacoes(i);
    end

% Efutua a estima��o da posi��o da fonte utilizando as fun�oes e algoritmos fornecidos 
% Simulation setup
    x = sourcePos';		% Posi��o da fonte

    D = squareform(pdist([x zeros(size(x)) a']'));
    d = D(1,3:end);				% dist�ncias fonte-�ncora
    an = D(2,3:end);			% normas das �ncoras

    P0 = 100;				% Pot�ncia da fonte
    P = P0./(d.^2);				% Pot�ncias das �ncoras sem ru�do

    stdev = 1e-1;				% Desvio padr�o

    P = P.*exp(stdev*randn(size(P)));	% Introdu��o de ru�do
    QP = 1e-2;
    P = QP*round(P/QP);			% Quantiza��o das pot�ncias

% Aplica��o do m�todo dos m�nimos quadrados
    A = [-2*repmat(P,[2 1]).*a'; -ones(size(P)); P]';
    b = (-P.*(an.^2))';

    z = A\b;
    xe = z(1:2);

    figure(2)
 
    plot(a*[1; 1i],'o'); hold all
    plot(x'*[1; 1i],'x'); plot(xe'*[1; 1i],'s'); hold off
    axis(100*[0 1 0 1]); axis('square')
    
    title('Estimativa da posi��o da fonte');

% RLS formulation (one-shot)
    RlsPar = struct('lam',1);
    [e,w,RlsPar] = qrrls(A,b,RlsPar);
    
%% Coment�rios
%
% Por observa��o da figura, podemos verificar que a posi��o estimada para a
% fonte(representada pelo quadrado) se encontra perto da posi��o real
% (representada pelo x).
% O erro associado � posi��o estimada deve-se principalmente � exist�ncia
% de ru�do.
%
%% Exerc�cio 2.c)
%
%  Representa��o da evolu��o temporal das probabilidades de cada estado ao
%  longo do tempo, para 3 condi��es iniciais diferentes
%
    load MarkovChain
    for k=1:3
% Condi��o inicial de probabilidades
    if k==1
        pi0 = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    end
    
    if k==2
        pi0 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0];
    end
    
    if k==3
        pi0 = [1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20];
    end
    
        pi(1,:) = pi0;
    
    for i=2:100
        pi(i,:) = pi(i-1, :)*P;
    end

    %Gera o vetor tempo usado para desenhar o gr�fico da evolu��o das probabilidades  
    time = linspace(0, 100, 100);
    
    % Desenha os gr�ficos que demonstram as evolu��es temporais das
    % probabilidades para as diferentes condi��es iniciais 
    figure(2+k)
    for i = 1:20
      state=linspace(i, i, 100);
      plot3(time, state, pi(:, i), "LineWidth", 3);
      hold on;
    end
    grid on;
    title(sprintf('Evolu��o das probabilidades para condi��o inicial %d',k));
    
    % Verifica que em todos os instantes de tempo a soma de probabilidades � 1  
    for i = 1:100
      X=sprintf('Somat�rio das probabilidades para t_%d = %.2f para condi��o inicial %d',i,sum(pi(i, :)),k);
      disp(X);
    end
    
    xlabel ('time'); ylabel('state'); zlabel('prob');
    end
%% Coment�rios
% Observando os gr�ficos apresentados podemos observar que
% independentemente da condi��o inicial escolhida, para um t
% suficientemente grande, os valores das probabilidades tendem para
% determinados valores limite, que verific�mos serem praticamente iguais
% aos valores obtidos na pergunta 2.a)
% Tamb�m se confirmou que a somat�rio das probabilidades para cada instante
% de tempo � 1.
%
% Nota: 
% Condi��o 1 - probabilidade 1 para estado 1
% Condi��o 2 - probabilidade 1 para estado 18
% Condi��o 3 - probabilidade 1/20 para todos os estados

%% Exerc�cio 2.d)
% An�lise do grafo de comunica��es entre agentes de forma a sugerir
% altera�oes aos pesos das liga�oes de forma a:
% 1-Melhorar a efic�cia de circula��o global do token
% 2-Dificultar a circula��o do token

    load MarkovChain
    
% Melhoria da Circula��o 
 
% Por an�lise das informa��es e dados obtidos nas perguntas anteriores decidimos que para
% melhorar a circula��o do token deviamos aumentar o peso das liga��es que
% formam os subgrupos onde o token passa menos tempo e dimunir os pesos das
% liga��es que formam os subgrupos onde o token passa mais tempo
% 

    P (3, 19) = 0.5; P (3, 12) = 0.5; P(12,3) = 0.3; P(12, 8)=0.35;P(12,10)=0.35;
    P (1,6) = 0.3; P(1,20) = 0.35; P(1,7) = 0.35;
    P(6,1) = 0.3; P(6,15) = 0.35; P(6,11) = 0.35;
 
    [Vetores_prop, Valores_prop] = eig(transpose(P));

    figure(6);
    
% O ciclo seguinte percorre o todos os valores pr�prios e guarda a posi��o daquele que tem valor 1  
    for i=1:size(Valores_prop,1)
        if(round(Valores_prop(i,i),4)==1)
            break;
        end
    end

% Normalizar os vetores proprios. � necess�rio calcular o valor do
% somatorio da norma

    vetor_normalizado_equipa = abs((Vetores_prop(:,i))./(sum((Vetores_prop(:,i)))));
    bar(vetor_normalizado_equipa);
    xlabel ('states'); ylabel('prob');
    xlim([0 21]);
    title('Probabilidades Limite da Cadeia de Markov (Melhoria da Circula��o)');
    
    for k=1:3
% Condi��o inicial de probabilidades
    if k==1
        pi0 = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    end
    
    if k==2
        pi0 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0];
    end
    
    if k==3
        pi0 = [1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20];
    end
    
        pi(1,:) = pi0;
    
    for i=2:100
        pi(i,:) = pi(i-1, :)*P;
    end
   

    %Gera o vetor tempo usado para desenhar o gr�fico da evolu��o das probabilidades  
    time = linspace(0, 100, 100);
    
    % Desenha os gr�ficos que demonstram as evolu��es temporais das
    % probabilidades para as diferentes condi��es iniciais 
    figure(6+k)
    for i = 1:20
      state=linspace(i, i, 100);
      plot3(time, state, pi(:, i), "LineWidth", 3);
      hold on;
    end
    grid on;
    title(sprintf('Evolu��o das probabilidades ap�s interven��o da equipa para cond inicial %d',k));
    xlabel ('time'); ylabel('state'); zlabel('probability');
    end
% De forma a observarmos os efeitos de uma circula��o melhorada do token na
% estimativa da posi��o da fonte, utilizamos o novamente o m�todo da alinea
% 2.b) alterando apenas a nossa matriz P

    observacoes = round(vetor_normalizado_equipa.*1000);
    a = zeros(sum(observacoes), 2);
    k1 = 1;
    k2 = 0;

% Gera observa��es para cada ancora, de forma a poder resolver o problema
% de minimos quadrados ponderado

    for i=1:size(observacoes)
        k2 = k2+observacoes(i);
        a(k1:k2,:) = repmat([nodePos(i,2) nodePos(i, 3)], observacoes(i), 1);
        k1 = k1 + observacoes(i);
    end

% Efutua a estima��o da posi��o da fonte utilizando as fun�oes e algoritmos fornecidos 
% Simulation setup
    n = 2;					% Embedding dimension
    x = sourcePos';		% Source position

    D = squareform(pdist([x zeros(size(x)) a']'));
    d = D(1,3:end);				% Source-anchor distances
    an = D(2,3:end);			% Anchor norms

% Generate observations
    P0 = 100;				% Source power
    P = P0./(d.^2);				% Noiseless RSSI

    stdev = 1e-1;				% Log-noise standard deviation

    P = P.*exp(stdev*randn(size(P)));	% Introduce noise
    QP = 1e-2;
    P = QP*round(P/QP);			% Quantize power measurements

% Localize source by least-squares
    A = [-2*repmat(P,[2 1]).*a'; -ones(size(P)); P]';
    b = (-P.*(an.^2))';

    z = A\b;
    xe = z(1:2);

    figure(11)
    
    plot(a*[1; 1i],'o'); hold all
    plot(x'*[1; 1i],'x'); plot(xe'*[1; 1i],'s'); hold off
    axis(100*[0 1 0 1]); axis('square')
    
    title('Estimativa da posi��o da fonte(Melhoria de Circula��o)');


% RLS formulation (one-shot)
    RlsPar = struct('lam',1);
    [e,w,RlsPar] = qrrls(A,b,RlsPar);
    
    
% Dificuldade � Circula��o
    load MarkovChain
    
    % Para dificultar a circula��o do token decidimos introduzir jamming na
    % liga��o mais fraca existente no nosso grafo, ou seja, eliminados a
    % liga��o existente entre os estados 3 e 12

    P(3,19) = 1; P(3,12) = 0;

    [Vetores_prop, Valores_prop] = eig(transpose(P));

    figure(10);

    % O ciclo seguinte percorre o todos os valores pr�prios e guarda a posi��o daquele que tem valor 1  
    for i=1:size(Valores_prop,1)
        if(round(Valores_prop(i,i),4)==1)
            break;
        end
    end
    
    vetor_normalizado_hostil = abs((Vetores_prop(:,i))./(sum((Vetores_prop(:,i)))));
    bar(vetor_normalizado_hostil);
    xlabel ('states'); ylabel('prob');
    xlim([0 21]);
    title('Probabilidades Limite da Cadeia de Markov (Dificulade � Circula��o)');
    
    for k=1:3
% Condi��o inicial de probabilidades
    if k==1
        pi0 = [1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0];
    end
    
    if k==2
        pi0 = [0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0];
    end
    
    if k==3
        pi0 = [1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20 1/20];
    end
    
        pi(1,:) = pi0;
    
    for i=2:100
        pi(i,:) = pi(i-1, :)*P;
    end

    %Gera o vetor tempo usado para desenhar o gr�fico da evolu��o das probabilidades  
    time = linspace(0, 100, 100);
    
    % Desenha os gr�ficos que demonstram as evolu��es temporais das
    % probabilidades para as diferentes condi��es iniciais 
    figure(11+k)
    for i = 1:20
      state=linspace(i, i, 100);
      plot3(time, state, pi(:, i), "Linewidth", 3);
      hold on;
    end
    grid on;
    title(sprintf('Evolu��o das probabilidades ap�s jamming para cond inicial %d',k));
    xlabel ('time'); ylabel('state'); zlabel('probability');
    end

%% Coment�rios 
% Observando o gr�fico de comunica��o entre agentes dispon�vel no guia de
% laborat�rio e os resultados obtidos na pergunta 2.a) verific�mos que
% existem 2 subgrupos onde o token pode circular durante bastante tempo,
% sendo eles os grupos: [19,13,4] e [7,20,1,6]. A influ�ncia destes
% subgrupos pode ser observada pelos ritmos de convergencia da al�nea
% anterior, uma vez que s�o estes os estados que mais rapidamente chegam
% a valor limite da sua probabilidade
%  
% Uma circula��o mais flu�da do token dever� permitir uma melhor
% precis�o na localiza��o da fonte, pois durante o processo de estimativa
% da mesma, a contribui��o de cada um dos estados seria melhor distribu�da
% e como tal, independentemente da posi��o da fonte, iriam existir mais
% medi��es diferentes, e como tal o c�lculo da posi��o seria mais preciso
%   
% Demonstramos que isto realmente acontece na figura ("Estimativa da 
% posi��o da fonte(Melhoria de Circula��o") onde usando o
% mesmo processo da alinea 2.b), mas com a matriz P modificada, estimamos
% a posi��o da fonte e tal como se pode verificar a posi��o estimada
% ficou mais proxima da real. Este resultado seria ainda melhor com mais
% mais testes, de modo a conseguir determinar a matriz P "ideal", isto �, a
% matriz P que permite uma homogeneiza��o perfeita das probabilidades.
%

%% Exerc�cio 3a - Simula��es de Monte Carlo
% Implementa��o do m�todo de Monte Carlo

load MarkovChain

M = 1000;
N = 100;

% Realizar M runs com N passos
% Gera matriz que vai conter os estados resultantes das simula��es de Monte Carlo
estados = zeros(M,N);  
conta_estados = zeros (1, 20);

% Inicializa barra de loading
processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;				% Pot�ncia da fonte
stdev = 1e-1;				% desvio padr�o

QP = 1e-2;

x = sourcePos';		% posi��o da fonte

% Matriz que vai conter a estimativa do erro para cada run e instante de
% tempo
matriz_erro = zeros(M,N);

for i=1:M % realiza as M runs
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    % Inicializa RlsPar em cada run
    RlsPar = struct('lam',1);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);				% dist�ncias fonte-�ncora
    an = D(2,3:end);			% norma das �ncoras
        
    Pot = P0./(d.^2);				% pot�ncias sem ru�do
    Pot = Pot.*exp(stdev*randn(size(Pot)));	% pot�ncia com ru�do
    Pot = QP*round(Pot/QP);			% quantiza��o das pot�ncias
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    % Estima��o RLS incremental
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N % realiza N passos para um dado estado inicial
        
        % Vetor que conta as ocorr�ncias de cada estado
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
            
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);				
        an = D(2,3:end);			
        
        Pot = P0./(d.^2);			
        Pot = Pot.*exp(stdev*randn(size(Pot)));
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end
        
        % Matriz de erro vai conter a norma entre a posi��o da fonte e da
        % estima��o atual
        matriz_erro(i,j) = norm(x-w(1:2));
        
        % Incrementa o processo da loading bar
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing'));
        
    end
    
end
     
% As probabilidades obt�m-se dividindo o n�mero de ocorr�ncias de um dado
% estado pelo n�mero de total de acontecimentos
probabilidades = conta_estados ./ (M*N);

graf_barras = [vetor_normalizado_2a probabilidades'];

% Representa o histograma
figure(15);
bar(graf_barras);
title("Probabilidade de cada estado (situa��o normal)");
xlabel("estado"); ylabel("probabilidade");
Position = [250    270    0.3568    0.0869];
legend("Distribui��o de Markov", "Distribui��o de Monte Carlo",'Position',  Position);


% Fecha loading bar
delete(f);

% Esta matriz vai conter a probabilidade de um estado ocorrer para cada
% instante de tempo
prob_estado=zeros(20, N);

for j=1:N
    for i=1:M
        % Calcula o n�mero de ocorr�ncias de cada estado para cada instante
        % de tempo e divide por M para obter a probabilidade
        prob_estado (estados(i,j), j) = prob_estado (estados(i,j),j)+1/M;
    end
end

 time = linspace(0, N, N);
    
 figure(5);
 for i = 1:20
      state=linspace(i, i, N);
      plot3(time, state, prob_estado(i,:), 'LineWidth', 0.5);
      hold on;
 end
title("Evolu��o da probabilidade no tempo (situa��o normal)");
xlabel ('time'); ylabel('state'); zlabel('probability');
legend("Markov(grosso)", "Monte Carlo(fino)", "location", "ne");

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

e1 = erro_media;

%% Coment�rios 3a - Situa��o normal
% Por compara��o dos histogramas torna-se �bvio que as simula��es de Monte
% Carlo est�o em concord�ncia com o m�todo da cadeia de Markov. No entanto,
% � de notar que isto s� � v�lido quando se realizam muitas runs ao longo
% de um extenso per�odo de tempo, visto que para simula��es pouco extensas,
% devido ao fator aleat�rio associado ao m�todo, existe uma grande
% vari�ncia no que toca aos resultados e � distribui��o de equil�brio.
% A evolu��o temporal tamb�m � semelhante, mas com imenso "ru�do".
% Novamente, isto deve-se � aleatoriedade do m�todo de Monte Carlo. A �nica
% forma de retificar este "ru�do" seria executar uma infinidade de runs de
% Monte Carlo.

%% Exerc�cio 3a - Com altera��o dos pesos pela equipa

load MarkovChain;

% Altera��o da matriz de probabilidades de transi��o para favorecer a
% equipa
 P (3, 19) = 0.5; P (3, 12) = 0.5; P(12,3) = 0.3; P(12, 8)=0.35;P(12,10)=0.35;
 P (1,6) = 0.3; P(1,20) = 0.35; P(1,7) = 0.35;
 P(6,1) = 0.3; P(6,15) = 0.35; P(6,11) = 0.35;
  
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);   
                    
conta_estados = zeros (1, 20);

processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;				
stdev = 1e-1;			

QP = 1e-2;

x = sourcePos';		

matriz_erro = zeros(M,N);

for i=1:M % realiza as M runs
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    RlsPar = struct('lam',1);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);			
    an = D(2,3:end);			
        
    Pot = P0./(d.^2);				
    Pot = Pot.*exp(stdev*randn(size(Pot)));
    Pot = QP*round(Pot/QP);			
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N 
        
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);			
        an = D(2,3:end);			
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));	
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,j) = norm(x-w(1:2));
        
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing: %.1f%%', processo*100/(M*N)));
        
    end
    
end
     
probabilidades = conta_estados ./ (M*N);

bar_graph = [vetor_normalizado_equipa probabilidades'];

figure(16);
bar(bar_graph);
title("Probabilidade de cada estado (Com interven��o da equipa)");
xlabel("estado"); ylabel("probabilidade");
Position = [300    270    0.3568    0.0869];
legend("Markov", "Monte Carlo",'Position',  Position);

delete(f);

prob_estado=zeros(20, N);

for j=1:N
    for i=1:M
        % Calcula o n�mero de ocorr�ncias de cada estado para cada instante
        % de tempo e divide por M para obter a probabilidade
        prob_estado (estados(i,j), j) = prob_estado (estados(i,j),j)+1/M;
    end
end

 time = linspace(0, N, N);
    
 figure(9);
 for i = 1:20
      state=linspace(i, i, N);
      plot3(time, state, prob_estado(i,:), 'LineWidth', 0.5);
      hold on;
 end
title("Evolu��o da probabilidade(Com interven��o da equipa)");
xlabel ('tempo'); ylabel('estado'); zlabel('probabilidade');
legend("Markov(grosso)","Monte Carlo(fino)", "Location", "ne");

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

e2 = erro_media;
 
%% Coment�rios do exerc�cio 3a - Com interven��o pela equipa
% Novamente, � f�cil notar que existe concord�ncia entre os resultados de
% Markov e emp�ricos, sendo agora a converg�ncia do m�todo emp�rico mais
% lenta. Isto deve-se ao facto das probabilidades entre transi��o de
% estados ser muito mais homog�nea, levando a maiores desvios da trajet�ria
% devido � aleatoriedade adicional (o dado que se lan�a para ver o estado 
% seguinte j� n�o est� t�o viciado).

 %% Exerc�cio 3a - Com altera��o dos pesos para simular jamming

load MarkovChain;

% Altera��o da matriz de probabilidades de transi��o para favorecer um
% elemento hostil
P(3,19) = 1; P(3,12) = 0;
P(19,7) = 0.05; P(19,3)=0.45;
P(1,6) = 0;P(1,20) =0.5; P(1,7) = 0.5;
 
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);  

conta_estados = zeros (1, 20);

processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;			
stdev = 1e-1;			

QP = 1e-2;

x = sourcePos';	

matriz_erro = zeros(M,N);

for i=1:M 
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    RlsPar = struct('lam',1);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);			
    an = D(2,3:end);			
    
    Pot = P0./(d.^2);				
    Pot = Pot.*exp(stdev*randn(size(Pot)));	
    Pot = QP*round(Pot/QP);		
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N 
        
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro      
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);				
        an = D(2,3:end);			
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));	
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,j) = norm(x-w(1:2));
        
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing: %.1f%%', processo*100/(M*N)));
        
    end
    
end
     
probabilidades = conta_estados ./ (M*N);

bar_graph = [vetor_normalizado_hostil probabilidades'];

figure(17);
bar(bar_graph);
title("Probabilidade de cada estado (Com interven��o hostil)");
xlabel("estado"); ylabel("probabilidade");
Position = [250    270    0.3568    0.0869];
legend("Distribui��o de Markov", "Distribui��o de Monte Carlo",'Position',  Position);

delete(f);

prob_estado=zeros(20, N);

for j=1:N
    for i=1:M
        % Calcula o n�mero de ocorr�ncias de cada estado para cada instante
        % de tempo e divide por M para obter a probabilidade
        prob_estado (estados(i,j), j) = prob_estado (estados(i,j),j)+1/M;
    end
end

 time = linspace(0, N, N);
    
 figure(14)
 for i = 1:20
      state=linspace(i, i, N);
      plot3(time, state, prob_estado(i,:));
      hold on;
 end

title("Evolu��o da probabilidade ao longo do tempo (Com interven��o hostil)");
xlabel ('tempo'); ylabel('estado'); zlabel('probabilidade');
legend("Markov(grosso)","Monte Carlo(fino)", "Location", "ne");

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

e3 = erro_media;

%% Coment�rios do exerc�cio 3a - Com interven��o de um elemento hostil
% A presen�a de jamming � �bvia por observa��o tanto do histograma, como da
% evolu��o das probabilidades. No entanto, nota-se uma grande diferen�a
% entre as distribui��es de Markov e Monte Carlo. � prov�vel que um aumento
% do n�mero de runs levaria a distribui��o de Monte Carlo para um
% equil�brio mais semelhante ao que observa na distribui��o de Markov.

%% Exerc�cio 3b - Evolu��o do erro ao longo do tempo 

load MarkovChain; 
 
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);  

conta_estados = zeros (1, 20);

processo = 0;

% Potencia e ruido
P0 = 100;				
stdev = 1e-1;				

QP = 1e-2;

x = sourcePos';	

matriz_erro = zeros(M,N);

for i=1:M 
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    % Remove os estados menos prov�veis de reter o token {3,8,9,10,12,17}
    if (estado_inicial==1) || (estado_inicial==2) || (estado_inicial==3) || (estado_inicial==4) || (estado_inicial==7) || (estado_inicial==13) || (estado_inicial==14) || (estado_inicial==16) || (estado_inicial==18) || (estado_inicial==19) || (estado_inicial==20)
        estados(i, :) = 0;
    else   
        estados (i, 1) = estado_inicial;
    
        estado_atual = estado_inicial;
    
        RlsPar = struct('lam',1);
    
        pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);			
        an = D(2,3:end);			
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));	
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,1) = norm(x-w(1:2));
    
        for j = 2:N
        
            conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
            estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
            estados (i, j) = estado_atual;
        
            % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
            % itera��o
            pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
            % estimativa do erro
            D = squareform(pdist([x zeros(size(x)) pos']'));
            d = D(1,3:end);				
            an = D(2,3:end);			
        
            Pot = P0./(d.^2);				
            Pot = Pot.*exp(stdev*randn(size(Pot)));
            Pot = QP*round(Pot/QP);		
        
            A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
            b = (-Pot.*(an.^2))';
        
            for k = 1:size(A,1)
                [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
            end

            matriz_erro(i,j) = norm(x-w(1:2));
            
        end 
    end
end     

% Ciclo que remove as linhas a mais da matriz (linhas a 0)
aux = 1;
for i=1:M
    if estados(aux,1)==0
        estados(aux,:) = [];
        aux = aux-1;
    end
    aux = aux+1;
end

time = linspace(0, N, N);

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

e4 =[e1; e2; e3; erro_media];

figure(18)
plot(time, e4);
grid on;
title("Evolu��o do erro ao longo do tempo");
legend("Situa��o normal", "Com interven��o da equipa", "Com interven��o hostil", "estados que tendem a reter o token");
xlabel("tempo"); ylabel("erro");

%% Coment�rios do exerc�cio 3.b)
% Dos gr�ficos representados � �bvio que o erro diminui com o aumento de
% passos realizados pelo token, como se esperava. Tamb�m � �bvio que para
% as diferentes variantes do problema, o erro evolui de forma diferente.
% Como se esperava, as altera��es feitas pela equipa (favorecendo a 
% circula��o) causaram uma diminui��o do erro. A presen�a de um elemento
% hostil causou um aumento do erro. Algo que � estranho � que o erro � mais
% baixo para os elementos que tendem a reter o token do que para a situa��o
% normal. Isto leva-nos � conclus�o que a reten��o do token, embora possa
% n�o convergir para um valor mais baixo para tempo infinito, permite uma
% estimativa razoav�l na mesma.

%% Exerc�cio 3c 
% Movimenta��o lenta com \lambda=1

load MarkovChain;

warning off;
 
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);  

conta_estados = zeros (1, 20);

processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;				
stdev = 1e-1;		

QP = 1e-2;

matriz_erro = zeros(M,N);

for i=1:M 
    % Reinicializa a posi��o da fonte para cada run
    x = sourcePos';		
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    RlsPar = struct('lam',1);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);			
    an = D(2,3:end);			
        
    Pot = P0./(d.^2);				
    Pot = Pot.*exp(stdev*randn(size(Pot)));
    Pot = QP*round(Pot/QP);			
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N 
        
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);			
        an = D(2,3:end);		
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,j) = norm(x-w(1:2));
        
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing: %.1f%%', processo*100/(M*N)));
        
        % Movimento lento da fonte
        x(1) = x(1) - 40/N;
        x(2) = x(2) + 30/N;
        
    end
    
end

delete(f);

time = linspace(0, N, N);

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

lambda1 = erro_media;

% Movimenta��o lenta de fonte com \lambda=0.1

load MarkovChain;

warning off;
 
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);  

conta_estados = zeros (1, 20);

processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;			
stdev = 1e-1;				

QP = 1e-2;

matriz_erro = zeros(M,N);

for i=1:M 
    
    % Reinicializa a posi��o da fonte para cada run
    x = sourcePos';		
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    RlsPar = struct('lam',0.1);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);				
    an = D(2,3:end);			
        
    Pot = P0./(d.^2);				
    Pot = Pot.*exp(stdev*randn(size(Pot)));	
    Pot = QP*round(Pot/QP);		
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N
        
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro      
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);				
        an = D(2,3:end);		
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));	
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,j) = norm(x-w(1:2));
        
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing: %.1f%%', processo*100/(M*N)));
        
        % Movimento lento da fonte
        x(1) = x(1) - 40/N;
        x(2) = x(2) + 30/N;
        
    end
    
end

delete(f);

time = linspace(0, N, N);

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

lambda01 = erro_media;
% Movimenta��o lenta de fonte com \lambda=0.85

load MarkovChain;

warning off;

x = sourcePos;	
a = [nodePos(:,2) nodePos(:, 3)];
 
% Realizar M runs com N passos
M=1000;
N=100;

estados = zeros(M,N);

conta_estados = zeros (1, 20);

processo = 0;
f = waitbar(processo, 'Starting');

% Potencia e ruido
P0 = 100;				
stdev = 1e-1;				

QP = 1e-2;

matriz_erro = zeros(M,N);

for i=1:M
    % Reinicializa a posi��o da fonte para cada run
    x = sourcePos';		
    
    pos=zeros(N, 2); % Inicializa vetor de posi��es a 0 para cada run
    
    estado_inicial = randi([1,20]); % Gera um estado inicial aleat�rio
    
    estados (i, 1) = estado_inicial;
    
    estado_atual = estado_inicial;
    
    RlsPar = struct('lam',0.85);
    
    pos(1,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
    % estimativa do erro
    D = squareform(pdist([x zeros(size(x)) pos']'));
    d = D(1,3:end);			
    an = D(2,3:end);		
        
    Pot = P0./(d.^2);			
    Pot = Pot.*exp(stdev*randn(size(Pot)));
    Pot = QP*round(Pot/QP);			
        
    A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
    b = (-Pot.*(an.^2))';
        
    for k = 1:size(A,1)
        [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
    end

    matriz_erro(i,1) = norm(x-w(1:2));
    
    for j = 2:N 
        
        conta_estados (estado_atual) = conta_estados (estado_atual) + 1;
        
        estado_atual = find (cumsum(P(estado_atual, :))>rand, 1 , 'first');
        
        estados (i, j) = estado_atual;
        
        % matriz de posi��es das �ncoras vai aumentar de tamanho com cada
        % itera��o
        pos(j,:) = [nodePos(estado_atual,2) nodePos(estado_atual,3)];
        
        % estimativa do erro   
        D = squareform(pdist([x zeros(size(x)) pos']'));
        d = D(1,3:end);				
        an = D(2,3:end);		
        
        Pot = P0./(d.^2);				
        Pot = Pot.*exp(stdev*randn(size(Pot)));	
        Pot = QP*round(Pot/QP);			
        
        A = [-2*repmat(Pot,[2 1]).*pos'; -ones(size(Pot)); Pot]';
        b = (-Pot.*(an.^2))';
        
        for k = 1:size(A,1)
            [e,w,RlsPar] = qrrls(A(k,:),b(k),RlsPar);
        end

        matriz_erro(i,j) = norm(x-w(1:2));
        
        processo = processo+1;
        waitbar (processo/(M*N), f, sprintf('Processing: %.1f%%', processo*100/(M*N)));
        
        % Movimento lento da fonte
        x(1) = x(1) - 40/N;
        x(2) = x(2) + 30/N;
        
    end
    
end

delete(f);

time = linspace(0, N, N);

for i=1:N
    erro_media(i) = mean(matriz_erro(:,i));
end

lambda = [lambda1; lambda01; erro_media];

figure(19)
plot(time, lambda);
grid on;
title("Evolu��o do erro ao longo do tempo (Situa��o normal)");
xlabel("tempo"); ylabel("erro");
legend("\lambda=1", "\lambda=0.1", "\lambda=0.85");

figure(20); hold on;
plot(a*[1; 1i],'o'); hold all
plot(sourcePos*[1; 1i],'x'); 
axis(100*[0 1 0 1]); axis('square')
plot(x'*[1; 1i],'*'); 
plot([sourcePos(1) x(1)], [sourcePos(2) x(2)], '--');
title("Movimento da fonte");
leg = legend("x - posi��o inicial da fonte", "* - posi��o final", "Location", "northeastoutside");

%% Coment�rios do exerc�cio 3.c)
% Fazendo uma trajet�ria lenta e retil�nea, representada na figura 
% "Movimento da fonte", espera-se que o fator de esquecimento tenha uma
% influ�ncia apreci�vel na estimativa da posi��o. Isto � confirmado, visto
% que para \lambda=0.1 o erro � elevado, porque o movimento da fonte �
% bastante lento. Para \lambda=1, devido a influ�ncia do passado, n�o �
% poss�vel fazer uma boa estimativa. Finalmente, a solu��o mais razo�vel a
% que se chegou foi \lambda=0.85. Embora n�o tenha sido testado devido ao
% tempo necess�rio para simular, espera-se que este valor de \lambda
% dependa do n�mero de steps que o token fez e ainda mais da trajet�ria
% efetuada pela fonte.